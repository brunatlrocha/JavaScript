function createEmoji (char) {
    const $el = document.createElement ('div')
    $el.classList.add ('emoji')
    $el.textContent = char

    return $el
}

function createName (name) {
    const $el = document.createElement ('p')
    $el.classList.add ('name')
    $el.textContent = name

    return $el
}

function createBox (emoji) {
    const $el = document.createElement ('div')
    $el.classList.add ('box')
    $el.append (createEmoji(emoji.char))
    $el.append (createName(emoji.name))

    return $el
}

const $emojiGallery = document.getElementById ('emojiGallery')

$emojiGallery.innerHTML= ''

const $frag = document.createDocumentFragment ()

for (const emojiBox of emoji) {
    $frag.append (createBox (emojiBox))
}

$emojiGallery.append($frag)

