document.addEventListener('DOMContentLoaded', function () {
    const movieList = document.getElementById('movieList');
    const searchInput = document.getElementById('searchInput');

    function displayMovies(movies) {
        movieList.innerHTML = '';

        movies.forEach(movie => {
            const listItem = document.createElement('li');
            listItem.textContent = `${movie.title} (${movie.year})`;

            const description = document.createElement('p');
            description.textContent = movie.description;

            description.style.display = 'none';

            listItem.appendChild(description);

            listItem.addEventListener('click', function () {
                if (description.style.display === 'none') {
                    description.style.display = 'block';
                } else {
                    description.style.display = 'none';
                }
            });

            movieList.appendChild(listItem);
        });
    }

    // Initial display of all movies
    displayMovies(movies);

    function filterMovies() {
        const query = searchInput.value.toLowerCase();
        const filteredMovies = movies.filter(movie => movie.title.toLowerCase().includes(query));
        displayMovies(filteredMovies);
    }

    searchInput.addEventListener('input', filterMovies);
});
